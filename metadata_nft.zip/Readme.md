## Steps

1. Run `npm install` in the terminal
2. Run `node index.js`